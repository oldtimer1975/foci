<!-- Template for pre-release GitHub release -->

<!-- TODO Post about this release to https://github.com/reactwg/react-native-releases/discussions) -->

- <!-- TODO List out notable picks for this patch -->

---

To test it, run:

npx react-native init RN__SHORT_VERSION__ --version __VERSION__

---

You can participate in the conversation on the status of this release in the [working group](https://github.com/reactwg/react-native-releases/discussions).

---

To help you upgrade to this version, you can use the [upgrade helper](https://react-native-community.github.io/upgrade-helper/) ⚛️

---

See changes from this release in the [changelog PR](https://github.com/facebook/react-native/labels/%F0%9F%93%9D%20Changelog)

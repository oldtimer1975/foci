# _Subsystem name_

[🏠 Home](path/to/main/__docs__/README.md)

_Description of the subsystem with the necessary context._

## 🚀 Usage

_Explanation of how the subsystem is used._

## 📐 Design

_Explain how the subsystem is designed, relevant implementation details, etc.
Ideally include an Excalidraw diagram._

## 🔗 Relationship with other systems

### Part of

- _A single bullet for the parent subsystem. Link to the documentation of that
  subsystem if it exists._

### Part of this

- _One bullet point for each subsystem that is part of this one. Link to the
  documentation of those subsystems if it exists._

### Used by this

- _One bullet point for each subsystem used by this one, explaining why it uses
  it and how. Link to the documentation of those subsystems if it exists._

### Uses this

- _One bullet point for each subsystem using this one, explaining why it uses it
  and how. Link to the documentation of those subsystems if it exists._
